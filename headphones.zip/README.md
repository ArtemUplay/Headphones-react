# Headphones

Web-проект

В данном проекте использовались такие технологии как React, scss-modules, Redux Toolkit.
